books = [
    {
        'id': 0,
        'title': 'Il nome della Rosa',
        'author': 'Umerto Eco',
        'year_published': '1980',
    },
    {
        'id': 1,
        'title': 'Il problema dei tre corpi',
        'author': 'Liu Cixin',
        'year_published': '2008',
    },
    {
        'id': 2,
        'title': 'Fondazione',
        'author': 'Isaac Asimov',
        'year_published': '1951',
    },
]